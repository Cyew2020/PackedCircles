Readme.txt
==========

https://github.com/rstudio/hex-stickers/blob/master/README.md